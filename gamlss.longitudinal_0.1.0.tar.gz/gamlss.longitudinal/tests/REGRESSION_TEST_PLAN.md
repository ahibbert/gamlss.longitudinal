# Regression Test Plan (Discussion Draft)

## Goal
Build a holistic regression suite for gamlss.longitudinal that protects:
- data validation and preprocessing behavior,
- model matrix construction (including interactions),
- likelihood/derivative paths (especially include_dlcopdpar = TRUE),
- fit summaries and plotting behavior,
- reproducibility across machines.

This document is for review before adding test code.

## Testing Framework Proposal
- Use testthat as the primary framework.
- Keep deterministic seeds in every simulation-based test.
- Split tests into small, fast unit tests and slower integration tests.
- Mark heavy optimization tests with skip_on_cran() and/or skip_if_not_installed().

## Proposed Test Structure
- tests/testthat/test-data-validation.R
- tests/testthat/test-formula-matrix.R
- tests/testthat/test-likelihood-derivatives.R
- tests/testthat/test-fit-smoke.R
- tests/testthat/test-plots-and-summary.R
- tests/testthat/test-backward-compatibility.R
- tests/testthat/test-edge-cases.R
- tests/testthat/helper-fixtures.R

## Priority Levels
- P0: must-have now (protect known breakages)
- P1: should-have soon (core stability)
- P2: nice-to-have (broader hardening)

---

## P0 Tests (Immediate)

### T001 - Factor time preserved as covariate
- Scope: gamlss.longitudinal preprocessing + formula mapping.
- Fixture: dataset with factor time and numeric subject.
- Assert:
  - Internal optimization path runs without factor arithmetic warnings.
  - Model matrix contains factor-expanded time covariate columns (not collapsed numeric trend).
  - No error when include_dlcopdpar = TRUE.

### T002 - Interaction expansion retained
- Scope: create_model_matrices via gamlss.longitudinal.
- Fixture: mu.formula with time*gender.
- Assert:
  - Fixed matrix includes main-effect columns for time and gender.
  - Fixed matrix includes at least one interaction column with ':' in name.
  - Fit object parameter names include interaction coefficients.

### T003 - include_dlcopdpar TRUE derivative path is numeric
- Scope: dlcopdpar branch and copula-margin derivatives.
- Fixture: small simulated dataset with missingness.
- Assert:
  - No non-numeric binary-op errors in derivative calculations.
  - No factor subtraction warnings.
  - Log-likelihood outputs are finite for marginal/copula/joint components.

### T004 - include_dlcopdpar parity smoke test
- Scope: model fit path consistency.
- Fixture: same deterministic dataset, fit with include_dlcopdpar FALSE and TRUE.
- Assert:
  - Both fits complete successfully.
  - Both produce finite joint logLik.
  - Parameter vector lengths are identical.

---

## P1 Tests (Core Stability)

### T101 - Required-input validation
- Missing time_var -> clear error.
- Missing subject_var -> clear error.
- Missing response variable in mu.formula -> clear error.

### T102 - Subject-time uniqueness check
- Fixture with duplicate subject-time pair.
- Assert: explicit validation error listing duplicate combinations.

### T103 - Full-grid expansion behavior
- Fixture with structurally missing subject-time rows.
- Assert:
  - Expansion inserts expected NA rows.
  - time_covariate is restored consistently after merge.

### T104 - Missingness hard stops
- Margin all missing at any time -> stop.
- Consecutive pair complete_pairs == 0 when total_pairs > 0 -> stop.

### T105 - Formula input normalization
- Accept formula objects and one-line strings.
- Strings without '~' are normalized correctly.
- Non-standard variable names map correctly.

### T106 - Smooth + fixed matrix coexistence
- Formula with s(age) + factor + interaction.
- Assert:
  - mm$x and mm$s both populated as expected.
  - smooth bases have expected row count.

### T107 - Starting values robustness
- Edge data causing non-finite Kendall tau.
- Assert: warning emitted and fallback tau = 0 behavior holds.

---

## P1 Plot and Summary Tests

### T151 - summary output contract
- Assert summary object has model stats and coefficient table.
- Assert coefficient table includes expected fields and finite estimates where applicable.

### T152 - plot.terms interaction rendering mode
- Fixture with interaction term(s).
- Assert:
  - plot_fixed_terms classifies interaction columns as factor-style output.
  - Returned plot metadata for interactions includes discrete levels.

### T153 - plot methods smoke tests
- plot(fit), plot(fit, time_stratified = TRUE), plot.terms(fit, data = ...).
- Assert: no errors and returned object includes dashboard/plots list.

---

## P2 Tests (Hardening)

### T201 - Character time handling
- Numeric-like character time accepted and converted.
- Non-numeric character time rejected with clear message.

### T202 - Single-level factor covariate behavior
- Ensure model matrix and plotting paths do not crash.

### T203 - Minimal time-point dataset
- Two-time-point data runs through fit and pair construction.

### T204 - Newdata forecast panel smoke test
- plot.gamlss.longitudinal with newdata and fallback data.
- Assert quantile columns are generated and panel object returned.

### T205 - Backward compatibility (numeric time workflow)
- Historical numeric-time fixture from prior behavior.
- Assert major outputs remain in expected ranges.

---

## Numerical Assertion Strategy
- Use tolerance-based comparisons for floating-point outputs.
- Suggested defaults:
  - expect_equal(..., tolerance = 1e-6) for deterministic algebra.
  - expect_equal(..., tolerance = 1e-4) for optimization-derived quantities.
- Prefer invariant checks over exact coefficient matching:
  - finite values,
  - monotonic improvements in selected diagnostics,
  - parameter vector dimensions and names.

## Fixture Strategy
- Add helper fixtures in tests/testthat/helper-fixtures.R:
  - make_fixture_factor_time_interaction(...)
  - make_fixture_numeric_time(...)
  - make_fixture_missingness_edge(...)
- Keep fixture sizes small by default (fast tests), plus one medium integration fixture.

## Suggested Rollout Order
1. Implement P0 tests first (T001-T004).
2. Add P1 validation/matrix tests (T101-T107).
3. Add plot/summary tests (T151-T153).
4. Add P2 hardening tests as needed.

## Acceptance Criteria for Initial Test Suite
- All P0 tests pass locally.
- At least 80 percent of P1 tests pass before release candidate.
- No new failures in legacy numeric-time workflow.
